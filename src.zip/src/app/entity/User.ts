export default class User {
    firstname: string = 'john';
    lastname: string = "Travolta";
    age: number = 0;
    gender: string = '';
    dob: Date = new Date();
    education:String='';
    // id:number;
}